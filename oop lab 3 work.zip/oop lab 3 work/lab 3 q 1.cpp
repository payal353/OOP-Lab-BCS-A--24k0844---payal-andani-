#include<iostream>
using namespace std;
class student{
	public:
	string name;
	int rollnum;
};

int main(){
 student s1;
 s1.name="payal";
 s1.rollnum=240844;
 cout<<"name: "<<s1.name<<endl;
 cout<<"roll: "<<s1.rollnum<<endl;	
}